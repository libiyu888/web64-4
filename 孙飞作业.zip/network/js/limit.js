$.fn.huiqv = function() {
	var huidaoding = document.documentElement.scrollTop || document.body.scrollTop;
	if (huidaoding > 0) {
		$(".gotop").show(0)
	} else {
		$(".gotop").hide(0)
	}
}
$.fn.huiqv();
window.onscroll = function() {
	$.fn.huiqv();
}
$(".gotop").on("click", function() {
	$("body,html").animate({
		scrollTop: 0
	});
})
$("header .nav").on("click", function() {
	if ($("body").width() < 768) {
		if ($(this).next().css("display") == "none") {
			$(this).next().slideDown();
		} else {
			$(this).next().stop(true, true).slideUp();
		}
	}


})
$("header .twomenu span").on("click", function() {
	if ($("body").width() < 768) {
		if ($(this).next().css("display") == "none") {
			$(this).next().slideDown();
		} else {
			$(this).next().stop(true, true).slideUp();
		}
	}

})

$("header .nav").parent().on("mouseover", function() {
	if ($("body").width() > 768) {
		$(this).children(".twomenu").show().parent().siblings().children(".twomenu").hide();
	}
})
$("header .nav").parent().on("mouseout", function() {
	if ($("body").width() > 768) {
		$(this).children(".twomenu").hide();
	}
})
$(".navmdbutton").on("click", function() {
	if ($(".pcandmd").css("display") == "none") {
		$(".pcandmd").slideDown();
	} else {
		$(".pcandmd").stop(true, true).slideUp();
	}
})
