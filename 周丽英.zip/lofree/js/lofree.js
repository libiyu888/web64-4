$(function(){
    $(window).on("resize", function(){
        /* 获取窗口的宽度 */
        let clientW = $(window).width();
        /* 设置临界点 */
        let isShowBigImg = clientW >= 768;
        //获取所有的item
        let allItem = $(".carousel-inner>.item");
        //遍历
        allItem.each((index , item) => {
            // console.log(item)
            //取出图片路径
            let src = isShowBigImg ? $(item).data("lg-img"): $(item).data("sm-img")
            let imgUrl = `url(${src})`;
            //设置背景
            $(item).css({
                backgroundImage: imgUrl
            })
            //创建img标签
            if(!isShowBigImg){
                let imgEle = `<img src="${src}">`;
                $(item).empty().append(imgEle)
            }else{
                $(item).empty()
            }
        })

    }).trigger("resize")
})
function changefs(){
    var iw=window.innerWidth;
    var fs=iw*100/1330;
    document.getElementsByTagName("html")[0].style.fontSize=fs+"px";
}
window.onresize=changefs;
changefs();

$(function(){
    $(".con").children().mouseenter(function(){
        $(this).animate({"width":"+=100px","height":"+=100px","top":"-=50px","left":"-=50px"},2000)
    }).mouseleave(function(){
        $(this).animate({"width":"-=100px","height":"-=100px","top":"+=50px","left":"+=50px"},2000)
    })
})
$(".con>img").mouseover(function(){
    $(this).amp();
})
$(function(){
    $(".cp-11").mouseenter(function(){
        $(this).children(".cp-1-1").css({"visibility":"hidden"}).end().children(".cp-1-2").css({"visibility":"unset"});
    })
    $(".cp-11").mouseleave(function(){
        $(this).children(".cp-1-1").css({"visibility":"unset"}).end().children(".cp-1-2").css({"visibility":"hidden"});
    })
})